
// Theme helpers
const rupiah = (num) => new Intl.NumberFormat('id-ID', {style:'currency', currency:'IDR', maximumFractionDigits:0}).format(num);

// Audio control (autoplay often blocked; user taps button to play)
const audio = document.getElementById('bg-audio');
const audioBtn = document.getElementById('audio-toggle');
if (audio && audioBtn){
  audioBtn.addEventListener('click', async () => {
    if (audio.paused) {
      try { await audio.play(); audioBtn.textContent = 'Hentikan Musik'; }
      catch(e){ console.warn('Autoplay blocked', e); }
    } else {
      audio.pause(); audioBtn.textContent = 'Putar Musik';
    }
  });
}

// Slider
const slider = document.getElementById('slider');
const slidesEl = slider.querySelector('.slides');
const imgs = Array.from(slidesEl.children);
const prev = slider.querySelector('.prev');
const next = slider.querySelector('.next');
const dots = slider.querySelector('.dots');
let index = 0;

imgs.forEach((_, i) => {
  const b = document.createElement('button');
  b.addEventListener('click', ()=>go(i));
  dots.appendChild(b);
});
const dotButtons = Array.from(dots.children);

function go(i){
  index = (i + imgs.length) % imgs.length;
  slidesEl.style.transform = `translateX(-${index*100}%)`;
  dotButtons.forEach((d,di)=>d.classList.toggle('active', di===index));
}
go(0);
prev.addEventListener('click', ()=>go(index-1));
next.addEventListener('click', ()=>go(index+1));
setInterval(()=>go(index+1), 5000);

// Simple scroll-into-view animation
const io = new IntersectionObserver((entries)=>{
  for (const e of entries){
    if (e.isIntersecting) e.target.classList.add('reveal');
  }
},{threshold:.15});

document.querySelectorAll('.fade-up').forEach(el=>io.observe(el));

// Product catalog
const catalog = [
  {id:'NG01', name:'Nugget Ayam Premium', price:32000, img:'assets/img/ayam-nugget.svg', unit:'500g'},
  {id:'SS02', name:'Sosis Sapi Jumbo', price:28000, img:'assets/img/sosis-sapi.svg', unit:'6 pcs'},
  {id:'DS03', name:'Dimsum Udang', price:36000, img:'assets/img/dimsum-udang.svg', unit:'12 pcs'},
  {id:'KG04', name:'Kentang Goreng Shoestring', price:30000, img:'assets/img/kentang-goreng.svg', unit:'1 kg'},
  {id:'BI05', name:'Bakso Ikan', price:27000, img:'assets/img/bakso-ikan.svg', unit:'500g'},
  {id:'MV06', name:'Mixed Veggies', price:22000, img:'assets/img/mix-veggies.svg', unit:'500g'},
];

const grid = document.getElementById('product-grid');
catalog.forEach(p => {
  const card = document.createElement('div');
  card.className = 'card fade-up';
  card.innerHTML = `
    <div class="thumb"><img src="${p.img}" alt="${p.name}"></div>
    <div class="body">
      <h4>${p.name}</h4>
      <p class="sub">${p.unit}</p>
      <p class="price">${rupiah(p.price)}</p>
    </div>
    <div class="actions">
      <button class="btn ghost add" data-id="${p.id}">Tambah</button>
      <div class="qty">
        <button class="dec" data-id="${p.id}">−</button>
        <span id="q-${p.id}">0</span>
        <button class="inc" data-id="${p.id}">+</button>
      </div>
    </div>
  `;
  grid.appendChild(card);
  io.observe(card);
});

// Cart system
const cart = JSON.parse(localStorage.getItem('lb_cart')||'{}');
const cartCount = document.getElementById('cart-count');
const cartDrawer = document.getElementById('cart-drawer');
const backdrop = document.getElementById('backdrop');
const cartItemsEl = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');

function saveCart(){ localStorage.setItem('lb_cart', JSON.stringify(cart)); }
function getProduct(id){ return catalog.find(x=>x.id===id); }
function qty(id){ return cart[id] || 0; }
function setQty(id, q){ if (q<=0) delete cart[id]; else cart[id]=q; saveCart(); render(); }
function add(id){ setQty(id, qty(id)+1); }
function dec(id){ setQty(id, qty(id)-1); }

function subtotal(){
  return Object.entries(cart).reduce((sum,[id,q]) => sum + getProduct(id).price*q, 0);
}

function render(){
  // update qty on cards
  catalog.forEach(p => {
    const span = document.getElementById(`q-${p.id}`);
    if (span) span.textContent = qty(p.id);
  });
  // badge
  const count = Object.values(cart).reduce((a,b)=>a+b,0);
  cartCount.textContent = count;
  // drawer items
  cartItemsEl.innerHTML = '';
  for (const [id, q] of Object.entries(cart)){
    const p = getProduct(id);
    const item = document.createElement('div');
    item.className = 'drawer-item';
    item.innerHTML = `
      <img src="${p.img}" alt="${p.name}" width="64" height="64">
      <div>
        <div class="title">${p.name}</div>
        <div class="sub">${p.unit} • ${rupiah(p.price)}</div>
      </div>
      <div class="qty">
        <button class="dec" data-id="${p.id}">−</button>
        <span>${q}</span>
        <button class="inc" data-id="${p.id}">+</button>
      </div>
    `;
    cartItemsEl.appendChild(item);
  }
  cartTotalEl.textContent = rupiah(subtotal());
  // checkout summary
  document.getElementById('summary-items').textContent = `${count} item`;
  const sub = subtotal();
  document.getElementById('summary-subtotal').textContent = rupiah(sub);
  const ongkir = 10000;
  document.getElementById('summary-ongkir').textContent = rupiah(ongkir);
  document.getElementById('summary-total').textContent = rupiah(sub + (count?ongkir:0));
}

document.addEventListener('click', (e)=>{
  const idAdd = e.target.closest('.add')?.dataset.id;
  const idInc = e.target.closest('.inc')?.dataset.id;
  const idDec = e.target.closest('.dec')?.dataset.id;
  if (idAdd) add(idAdd);
  if (idInc) add(idInc);
  if (idDec) dec(idDec);
});

// Drawer open/close
document.getElementById('cart-button').addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
backdrop.addEventListener('click', closeDrawer);
function openDrawer(){ cartDrawer.classList.add('open'); backdrop.classList.add('show'); }
function closeDrawer(){ cartDrawer.classList.remove('open'); backdrop.classList.remove('show'); }

// Jump to checkout via button
document.getElementById('go-checkout').addEventListener('click', closeDrawer);

// Checkout form (demo)
document.getElementById('checkout-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const lines = Object.entries(cart).map(([id,q]) => {
    const p = getProduct(id);
    return `- ${p.name} x${q} = ${rupiah(p.price*q)}`;
  }).join('\n');
  const summary = `Halo, saya {nama}. Saya ingin pesan:\n${lines}\nTotal: ${rupiah(subtotal()+10000)}\nAlamat: {alamat}\nPembayaran: {metode}\nKontak: {wa}`
    .replace('{nama}', data.nama)
    .replace('{alamat}', data.alamat)
    .replace('{metode}', data.metode)
    .replace('{wa}', data.wa);
  alert('Pesanan dibuat! Rangkuman siap dikirim via WhatsApp:\n\n' + summary);
  // Optional: open WhatsApp prefill (commented to avoid popup)
  // window.open(`https://wa.me/?text=${encodeURIComponent(summary)}`, '_blank');
});

render();
